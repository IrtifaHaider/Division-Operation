package com.example.swlab6;

/**
 * This class provides methods for performing division operations
 * with overloads for different numbers of parameters.
 */
public class DivisionCalculatation {

    private double numerator;
    private double denominator;

    // Parameterized constructor to initialize numerator and denominator
    public DivisionCalculatation(double numerator, double denominator) {
        if (denominator == 0) {
            throw new ArithmeticException("Division by zero is not allowed.");
        }
        this.numerator = numerator;
        this.denominator = denominator;
        System.out.println("DivisionCalculatation object created with initial values.");
    }

    /**
     * Divides the stored numerator by the stored denominator.
     *
     * @return The result of the division.
     * @throws ArithmeticException If the denominator is zero.
     */
    public double divide() {
        return numerator / denominator;
    }

    /**
     * Divides the given numerator by the given denominator.
     *
     * @param numerator The value to be divided (numerator).
     * @param denominator The value by which the numerator is divided (denominator).
     * @return The result of the division.
     * @throws ArithmeticException If the denominator is zero.
     */
    public double divide(double numerator, double denominator) {
        if (denominator == 0) {
            throw new ArithmeticException("Division by zero is not allowed.");
        }
        return numerator / denominator;
    }

    /**
     * Divides the given numerator by the given denominator, then multiplies the result by the multiplier.
     *
     * @param numerator The value to be divided (numerator).
     * @param denominator The value by which the numerator is divided (denominator).
     * @param multiplier The value to multiply the result of the division.
     * @return The result of the division, multiplied by the multiplier.
     * @throws ArithmeticException If the denominator is zero.
     */
    public double divide(double numerator, double denominator, double multiplier) {
        if (denominator == 0) {
            throw new ArithmeticException("Division by zero is not allowed.");
        }
        return (numerator / denominator) * multiplier;
    }
}
