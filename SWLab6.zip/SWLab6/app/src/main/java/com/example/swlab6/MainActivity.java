package com.example.swlab6;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * MainActivity class that demonstrates the use of the DivisionCalculatation class
 * to perform division operations and handle different types of division calculations.
 */
public class MainActivity extends AppCompatActivity {

    private EditText numeratorInput;
    private EditText denominatorInput;
    private EditText multiplierInput;
    private TextView resultText;

    /**
     * Called when the activity is first created.
     * This method sets up the layout and calls the DivisionCalculatation methods to perform
     * division operations. The results are logged for demonstration and displayed on the screen.
     *
     * @param savedInstanceState If the activity is being re-initialized after previously being shut down,
     *                           this contains the data it most recently supplied in {@link #onSaveInstanceState(Bundle)}.
     *                           Otherwise, it is null.
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize the UI components
        numeratorInput = findViewById(R.id.numeratorInput);
        denominatorInput = findViewById(R.id.denominatorInput);
        multiplierInput = findViewById(R.id.multiplierInput);
        resultText = findViewById(R.id.resultText);
        Button performDivisionButton = findViewById(R.id.performDivisionButton);

        // Set an OnClickListener for the button
        performDivisionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performDivision();
            }
        });
    }

    /**
     * Method to perform division based on user input and display the result.
     */
    private void performDivision() {
        try {
            // Get user inputs
            String numeratorStr = numeratorInput.getText().toString();
            String denominatorStr = denominatorInput.getText().toString();
            String multiplierStr = multiplierInput.getText().toString();

            // Convert inputs to double
            double numerator = Double.parseDouble(numeratorStr);
            double denominator = Double.parseDouble(denominatorStr);

            // Check for division by zero in user input
            if (denominator == 0) {
                throw new ArithmeticException("Division by zero is not allowed.");
            }

            // Instantiate DivisionCalculatation class with numerator and denominator
            DivisionCalculatation divResult = new DivisionCalculatation(numerator, denominator);

            double result;
            if (!multiplierStr.isEmpty()) {
                // Perform division with multiplier
                double multiplier = Double.parseDouble(multiplierStr);
                result = divResult.divide(numerator, denominator, multiplier);
                Log.d("DivisionResult", "Result (three params - with multiplier): " + result);
            } else {
                // Perform simple division using the parameterized constructor values
                result = divResult.divide();
                Log.d("DivisionResult", "Result (two params): " + result);
            }

            // Display the result on the screen
            resultText.setText("Result: " + result);

        } catch (NumberFormatException e) {
            // Handle invalid input
            Toast.makeText(this, "Please enter valid numbers", Toast.LENGTH_SHORT).show();
        } catch (ArithmeticException e) {
            // Handle division by zero
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}
